/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capstone2;

import javax.swing.*;

/**
 *
 * @author Aaron Spero
 */
public class RegisterPanel extends javax.swing.JPanel {

    private StartFrame parent;
    private int origin;
    /**
     * Creates new form RegisterPanel
     */
    public RegisterPanel(StartFrame parent, int origin) {
        this.parent = parent;
        this.origin = origin;
        initComponents();
        setOpaque(false);
    }
    
    public void setOrigin(int origin) {
        this.origin = origin;
    }

    private void verifyRegistration() {
        
        String errorString = "";
        boolean errorStatus = false;
        boolean emailFlag = true;
        String[] validEmailDomains = {"gmail.com", "yahoo.com","hotmail.com",
            "aol.com","gmail.com", "yahoo.com", "hotmail.com", "aol.com", "hotmail.co.uk", 
            "hotmail.fr", "msn.com", "yahoo.fr", "wanadoo.fr", "orange.fr", "comcast.net", 
            "yahoo.co.uk", "yahoo.com.br", "yahoo.co.in", "live.com", "rediffmail.com", 
            "free.fr", "gmx.de", "web.de", "yandex.ru", "ymail.com", "libero.it", "outlook.com", 
            "uol.com.br", "bol.com.br", "mail.ru", "cox.net", "hotmail.it", "sbcglobal.net", "sfr.fr", 
            "live.fr", "verizon.net", "live.co.uk", "googlemail.com", "yahoo.es", "ig.com.br", "live.nl", 
            "bigpond.com", "terra.com.br", "yahoo.it", "neuf.fr", "yahoo.de", "alice.it", 
            "rocketmail.com", "att.net", "laposte.net", "facebook.com", "bellsouth.net", "yahoo.in", 
            "hotmail.es", "charter.net", "yahoo.ca", "yahoo.com.au", "rambler.ru", "hotmail.de", 
            "tiscali.it", "shaw.ca", "yahoo.co.jp", "sky.com", "earthlink.net", "optonline.net", 
            "freenet.de", "t-online.de", "aliceadsl.fr", "virgilio.it", "home.nl", "qq.com", 
            "telenet.be", "me.com", "yahoo.com.ar", "tiscali.co.uk", "yahoo.com.mx", "voila.fr", 
            "gmx.net", "mail.com", "planet.nl", "tin.it", "live.it", "ntlworld.com", "arcor.de", 
            "yahoo.co.id", "frontiernet.net", "hetnet.nl", "live.com.au", "yahoo.com.sg", "zonnet.nl", 
            "club-internet.fr", "juno.com", "optusnet.com.au", "blueyonder.co.uk", "bluewin.ch", 
            "skynet.be", "sympatico.ca", "windstream.net", "mac.com", "centurytel.net", "chello.nl", 
            "live.ca", "aim.com", "bigpond.net.au"};
        
        for(int k = 0; k < validEmailDomains.length; k++) {
            if(emailTF.getText().contains(validEmailDomains[k])) {
                emailFlag = false;
                break;
            }
            
        }
        
        if(emailTF.getText().equals("")) {
            errorStatus = true;
            errorString = errorString + "*E-mail field is empty.\r\n";
        }
        else if(!emailTF.getText().contains("@")) {
            errorStatus = true;
            errorString = errorString + "*Not a valid e-mail address.\r\n";
        }
        else if(emailFlag) {
            errorStatus = true;
            errorString = errorString + "*Not a recognized e-mail domain\r\n";
        }
        
        //to be implemented!!!!
        else if(false) {
            errorStatus = true;
            errorString = "*This e-mail is already in use with another account.\r\n";
        }
        
        if(usernameTF.getText().equals("")) {
            errorStatus = true;
            errorString = errorString + "*Username field is empty.\r\n";
        }
        else if(usernameTF.getText().length() < 6) {
            errorString = errorString + "*Username must be at least 6 characters long.\r\n";
        }
        
        //to be implemented!!!!
        else if(false) {
            errorString = "*Username already in use. Please select a different username.\r\n";
        }
        //create an inappropriate name filter?
        
        if(screennameTF.getText().equals("")) {
            errorString = errorString + "*Screenname field is empty.\r\n";
        } 
        if(new String(passwordPF.getPassword()).equals("")) {
            errorString = errorString + "*Password field is empty.\r\n";
        } 
        else if(passwordPF.getPassword().length < 8) {
            errorString = errorString + "*Password field must be at least 8 characters long.\r\n";
        }
        else if(!(new String(passwordPF.getPassword()).equals(
                new String(confirmPasswordPF.getPassword())))) {
            errorString = errorString + "*Your password and confirmation password"
                    + " do not match.\r\n";
        }
        if(new String(confirmPasswordPF.getPassword()).equals("")) {
            errorString = errorString + "*Confirm Password field is empty.\r\n";
        } 
        
        System.out.println(errorString);
        if(errorStatus) {
            JOptionPane.showMessageDialog(this, errorString, "Registration Error", 
                            JOptionPane.ERROR_MESSAGE);
        }
        else {
            
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        emailLabel = new javax.swing.JLabel();
        usernameLabel = new javax.swing.JLabel();
        screennameLabel = new javax.swing.JLabel();
        passwordLabel = new javax.swing.JLabel();
        confirmPasswordLabel = new javax.swing.JLabel();
        emailTF = new javax.swing.JTextField();
        usernameTF = new javax.swing.JTextField();
        screennameTF = new javax.swing.JTextField();
        passwordPF = new javax.swing.JPasswordField();
        confirmPasswordPF = new javax.swing.JPasswordField();
        createAccountButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        emailLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        emailLabel.setText("E-mail:");

        usernameLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        usernameLabel.setText("Username:");

        screennameLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        screennameLabel.setText("Screenname:");

        passwordLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        passwordLabel.setText("Password:");

        confirmPasswordLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        confirmPasswordLabel.setText("Confirm Password:");

        emailTF.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        emailTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailTFActionPerformed(evt);
            }
        });

        usernameTF.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        usernameTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameTFActionPerformed(evt);
            }
        });

        screennameTF.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        passwordPF.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        confirmPasswordPF.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        createAccountButton.setBackground(new java.awt.Color(255, 153, 0));
        createAccountButton.setText("Create Account");
        createAccountButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createAccountButtonActionPerformed(evt);
            }
        });

        backButton.setBackground(new java.awt.Color(255, 153, 0));
        backButton.setText("Back ");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        jLabel1.setText("(The name other users will see)");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(emailLabel)
                            .addComponent(usernameLabel)
                            .addComponent(screennameLabel)
                            .addComponent(passwordLabel)
                            .addComponent(confirmPasswordLabel)
                            .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(screennameTF)
                                .addComponent(usernameTF)
                                .addComponent(passwordPF)
                                .addComponent(emailTF)
                                .addComponent(confirmPasswordPF, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(createAccountButton, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emailTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emailLabel))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(usernameLabel)
                    .addComponent(usernameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(screennameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(screennameLabel)))
                .addGap(1, 1, 1)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passwordLabel)
                    .addComponent(passwordPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmPasswordLabel)
                    .addComponent(confirmPasswordPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(createAccountButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backButton))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void emailTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailTFActionPerformed

    private void usernameTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameTFActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        if(origin == 0) {
            parent.launchTitlePage(this);
        } else if(origin == 1) {
            parent.launchUserLogin(this);
        }
    }//GEN-LAST:event_backButtonActionPerformed

    private void createAccountButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createAccountButtonActionPerformed
        verifyRegistration();
    }//GEN-LAST:event_createAccountButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JLabel confirmPasswordLabel;
    private javax.swing.JPasswordField confirmPasswordPF;
    private javax.swing.JButton createAccountButton;
    private javax.swing.JLabel emailLabel;
    private javax.swing.JTextField emailTF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JPasswordField passwordPF;
    private javax.swing.JLabel screennameLabel;
    private javax.swing.JTextField screennameTF;
    private javax.swing.JLabel usernameLabel;
    private javax.swing.JTextField usernameTF;
    // End of variables declaration//GEN-END:variables
}
