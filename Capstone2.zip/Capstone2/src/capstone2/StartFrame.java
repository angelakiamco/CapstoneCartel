/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capstone2;

/**
 *
 * @author Aaron Spero
 */

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.swing.*;
import java.sql.*;
import javax.imageio.ImageIO;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import org.netbeans.lib.awtextra.*;

public class StartFrame extends JFrame {
    
    private JLabel mafiaCig;
    TitlePanel mainPanel;
    LoginPanel loginScreen;
    RegisterPanel registerScreen;
    ResetPassPanel resetPassScreen;
    
    
    public StartFrame() {
        
//        mafiaCig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mafiacig2.jpg"))); 
//
//        mafiaCig.setMinimumSize(new java.awt.Dimension(1060, 400));
//        mafiaCig.setPreferredSize(new java.awt.Dimension(1060, 400));
//        getContentPane().add(mafiaCig, new AbsoluteConstraints(0, 0, 1060, 570));
 
        JLabel contentPane = new JLabel();
        contentPane.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mafiacig2.jpg")));
        
        setContentPane( contentPane );
    
            mainPanel = new TitlePanel(this);
            
        getContentPane().setLayout(new AbsoluteLayout());
        
        getContentPane().add(mainPanel, new AbsoluteConstraints(820, 30, 300, 400));

        setTitle("The Cartel");
        setSize(1068,600);
        setLocation(200,100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);

    }

    
    public void launchTitlePage(JPanel currentPanel) {
        getContentPane().remove(currentPanel);
        getContentPane().add(mainPanel, new AbsoluteConstraints(820, 30, 300, 400));
        
        repaint();
        revalidate();
    }
    
    public void launchUserLogin(JPanel currentPanel) {
        getContentPane().remove(currentPanel);
       
        if(loginScreen == null) {
            loginScreen = new LoginPanel(this);
        }
        
        getContentPane().add(loginScreen, new AbsoluteConstraints(600, 50, 500, 325));
        repaint();
        revalidate();
    }
    
    public void launchRegister(JPanel currentPanel, int origin) {
        getContentPane().remove(currentPanel);
        
        if(registerScreen == null) {
            registerScreen = new RegisterPanel(this, origin);
        } else {
            registerScreen.setOrigin(origin);
        }
        
        getContentPane().add(registerScreen, new AbsoluteConstraints(600, 50, 426, 342));
        repaint();
        revalidate();
        
    }
    
    public void launchResetPass(JPanel currentPanel) {
        getContentPane().remove(currentPanel);
        
        if(resetPassScreen == null) {
            resetPassScreen = new ResetPassPanel(this);
        }
        
        getContentPane().add(resetPassScreen, new AbsoluteConstraints(550, 50, 493, 322));
        repaint();
        revalidate();
    }
    
    public static void main(String[] args) {
        new StartFrame();
    }
    
}
